package de.diebohne.alles;

public class WerbeKampagne {

	// ********************************************************
	// *** Attribute
	// ********************************************************
	private String titel;
	private String werbetext;
	private int dauer;
	private Kunde[] kunden;

	// ********************************************************
	// *** Methoden
	// ********************************************************

	public void benachrichtigen() {

		// um nicht in die Exception-Situation zu kommen, wird abgefangen, ob es das
		// Array kunden gibt
		if (kunden == null) {
			System.out.println("Es wurden keine Kunden gewählt, Benachrichtigungen sind nicht möglich.");
			return;
		}
		if (titel == null || dauer == 0 || werbetext == null) {
			System.out.println("Informationen unvollständig");
			return;
		}
		for (int i = 0; i < kunden.length; i++) {
			Kunde derKunde = kunden[i]; // eine weitere Referenzvariable, die nur die Adresse enthält. Dann muss man
										// späer nicht mit Index[] coden. Greift auf die Klasse "Kunde" zu, innerhalb
										// des Projekts
			// abfragen, ob es den Kunden mit dem Index gibt
			if (derKunde == null) {
				System.out.println("Lücken im Array, bitte an Marketing wenden");
				continue; // die Schleife wird am Schleifenkopf fortgeführt (mit i++). Die Schleife wird
							// nicht abgebrochen
			}
			// Werbezustimmung abfragen
			if (derKunde.isWerbungErlaubt()) {
				// hier wird "Lieblingskunde" angedruckt, wenn der Name nicht befüllt ist
				String anrede = derKunde.getName();
				if (anrede == null) {
					anrede = "Lieblingskunde";
				}
				String anzeigeText = "\nWichtige Info für Dich, " + anrede + ". von \"Die Bohne\"";
				anzeigeText = anzeigeText + "\n\t" + titel;
				anzeigeText += "\n\tFür die nächsten " + dauer + " Tage gilt: "; // ist kein clean Code, setzt aber
																					// jeder ein
				anzeigeText += "\n\t" + werbetext;
				System.out.println(anzeigeText);
			}
		}
	}
	// ********************************************************
	// *** getter-/ setter-Methoden wegen Datenkapselung
	// ********************************************************

	public void setKunden(Kunde[] dieAusgewaehltenKunden) {
		kunden = dieAusgewaehltenKunden;
	}

	public void setDauer(int dauerInTagen) {
		dauer = dauerInTagen;
	}

	public void setTitel(String derTitel) {
		titel = derTitel;
	}

	public void setWerbetext(String derWerbetext) {
		boolean enthaeltStarbucks = derWerbetext.contains("Starbucks");
		if (enthaeltStarbucks == true) {
		}
		werbetext = derWerbetext;
	}

}
