package de.diebohne.alles;

public class Kunde {

	// *************** Attribute *************

	private String name;
	private double rechnungsHoehe;
	private boolean werbungErlaubt; // Das angibt, ob der Kunde Werbung erhalten möchte (true) oder nicht (false).

	// *************** Methoden **************

	public void bestellen(double preis) {
		rechnungsHoehe = rechnungsHoehe + preis;
	}

	public void bezahlen() {
		rechnungsHoehe = 0;
	}

	public void aendernDerWerbeeinstellung() {   // Die Methode aendernDerWerbeeinstellung() ist eine praktische Funktion,
												 // um die Zustimmung des Kunden zur Werbung schnell und effizient zu ändern
												
		werbungErlaubt = !werbungErlaubt;    // Durch die Zuweisung werbungErlaubt = !werbungErlaubt; wird der aktuelle
											 // Wert von werbungErlaubt umgekehrt.
	}

	// ************* Getter & Setter-Methoden **************
    
	/**
	 * Diese Methoden sind ein wichtiger Bestandteil der objektorientierten Programmierung, um die Integrität der Daten zu 
	 * gewährleisten.
	 * 
	 * Getter: Ermöglichen das Auslesen der privaten Attribute (name, rechnungsHoehe, werbungErlaubt).
	 * Setter: Ermöglichen das Setzen oder Ändern der privaten Attribute.
	 * 
	 * Vorteile:
	 * 
	 * Kontrollierter Zugriff auf die Attribute.
	 * Möglichkeit, zusätzliche Logik (z. B. Validierung) in die Setter-Methoden einzubauen.
	 * Kapselung der Daten, sodass die interne Darstellung der Attribute von außen verborgen bleibt.
	 * @return
	 */
	public String getName() {  // Gibt den Namen des Kunden zurück
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	//N.B. Wenn man den Namen des Kunden abfragen möchte, ruft man diese Methode auf. Zum Beispiel:
	
	// Kunde kunde = new Kunde();
	// kunde.setName("Max Mustermann");
	// String name = kunde.getName(); // Gibt "Max Mustermann" zurück

	public double getRechnungsHoehe() {  // Gibt die aktuelle Rechnungshöhe des Kunden zurück.
		return rechnungsHoehe;
	}
	public void setRechnungsHoehe(double rechnungsHoehe) {
		this.rechnungsHoehe = rechnungsHoehe;
	}
	
	// Wenn man die Rechnungshöhe des Kunden abfragen möchte, ruft man diese Methode auf. Beispiel:

    // Kunde kunde = new Kunde();
    // kunde.bestellen(100.0);
    // double rechnung = kunde.getRechnungsHoehe(); // Gibt 100.0 zurück

	public boolean isWerbungErlaubt() {
		return werbungErlaubt;
	}
	public void setWerbungErlaubt(boolean werbungErlaubt) {
		this.werbungErlaubt = werbungErlaubt;
	}
	
	// Hinweis: Für boolean-Attribute wird oft "is" anstelle von "get" im Methodennamen verwendet. Beispiel:

    //Kunde kunde = new Kunde();
    //kunde.setWerbungErlaubt(true);
    //boolean erlaubt = kunde.isWerbungErlaubt(); // Gibt true zurück

}
