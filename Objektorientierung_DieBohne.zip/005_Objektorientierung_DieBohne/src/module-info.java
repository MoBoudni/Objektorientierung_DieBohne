/**
 * 
 */
/**
 * 
 */
module Objektorientierung_DieBohne {
}